class SluckRouteController{

    // GET /:sluckroute
    index = (req, res) => {
        res.sendStatus(404)
    }
}

module.exports = new SluckRouteController